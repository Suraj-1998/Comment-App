﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Feedback_Suraj
{
    public partial class Home : System.Web.UI.Page
    {
        DataBaseOperation dataBaseOperation = new DataBaseOperation();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx",false);
            }
            else
            {
                if (!IsPostBack)
                {
                    LoadComments();
                }
            }
        }

        private void LoadComments()
        {
            int count = 1;
            try
            {
                US1.Text = string.Empty;
                Cmt1.Text = string.Empty;
                US2.Text = string.Empty;
                Cmt2.Text = string.Empty;
                Dictionary<string, string> comments = dataBaseOperation.GetCommentsDetails();
                if (comments.Count() > 0)
                {
                    foreach (KeyValuePair<string, string> k in comments)
                    {
                        if (count > 2)
                            break;
                        if (count == 1)
                        {
                            US1.Text = k.Key;
                            US1.Visible = true;
                            Cmt1.Text = k.Value;
                        }
                        else if (count == 2)
                        {
                            US2.Text = k.Key;
                            US2.Visible = true;
                            Cmt2.Text = k.Value;
                        }

                        count++;

                    }
                }
                else
                {
                    US1.Visible = false;
                    US2.Visible = false;
                    Cmt1.Visible = false;
                    Cmt2.Visible = false;
                }
            }
            catch(Exception e)
            {

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string comments = txtarea.InnerText;
                string user = Session["User"].ToString();
                dataBaseOperation.InsertCommentsDetails(user, comments);
            }
            catch(Exception ex)
            {

            }
        }

        protected void Filter_Click(object sender, EventArgs e)
        {
            int count = 1;
            try
            {
                string user = Session["User"].ToString();
                US1.Text = string.Empty;
                Cmt1.Text= string.Empty;
                US2.Text = string.Empty;
                Cmt2.Text = string.Empty;
                List<string> comments =dataBaseOperation.GetCommentsDetailsFilter(user);
                foreach (string comment in comments)
                {
                    if (count > 2)
                        break;
                    if (count == 1)
                    {
                        US1.Text = user;
                        US1.Visible = false;
                        Cmt1.Text = comment;
                    }
                    else if (count == 2)
                    {
                        US2.Text = user;
                        US2.Visible = false;
                        Cmt2.Text = comment;
                    }

                    count++;

                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}