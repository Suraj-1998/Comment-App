﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Feedback_Suraj
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session["LoginMode"] = "Sign In";
                SecretRow.Visible = false;
            }
        }

        protected void lnkSignUp_Click(object sender, EventArgs e)
        {
            if (Session["LoginMode"].ToString() == "Sign In")
            {
                SecretRow.Visible = true;
                LinkButton1.Visible = false;
                header.InnerText = "Sign Up";
                btnSignIn.Text = "Sign Up";
                Session["LoginMode"] = "Sign Up";
                para.InnerText = "Already have an account?";
                lnkSignUp.Text = "Sign In";
                
            }
            else
            {
                SecretRow.Visible = false;
                LinkButton1.Visible = true;
                header.InnerText = "Sign In";
                btnSignIn.Text = "Sign In";
                Session["LoginMode"] = "Sign In";
                para.InnerText = "Don't have a account?";
                lnkSignUp.Text = "Sign Up";
                
            }
        }

        protected void btnSignIn_Click(object sender, EventArgs e)
        {
            DataBaseOperation dataBaseOperation = new DataBaseOperation();
            if (Session["LoginMode"].ToString() == "Sign In")
            {
                string email = txtEmail.Text;
                string password = Encrytion(txtPassword.Text);
                bool result = dataBaseOperation.GetUserDetails(email, password);
                if(result==true)
                {
                    Session["User"]= txtEmail.Text;
                    Response.Redirect("Home.aspx", false);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + " Invalid Username/Password "   + "');", true);
                }
            }
            else if (Session["LoginMode"].ToString() == "Sign Up")
            {
                string email = txtEmail.Text;
                string epassword = Encrytion(txtPassword.Text);
                string secretCode = Encrytion(txtSecret.Text);
                
                dataBaseOperation.InsertUserDetails(email, epassword, secretCode);
            }
            else
            {
                string email = txtEmail.Text;
                string secretCode = Encrytion(txtSecret.Text);
                string password = Decryption(dataBaseOperation.GetPassword(email,secretCode ));
                if(string .IsNullOrEmpty(password))
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + " Invalid Secret Code " + "');", true);
                else
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "Your Password is " + password + "');", true);

              
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            PassRow.Visible = false;
            lnkSignUp.Visible = false;
            LinkButton1.Visible = false;
            para.Visible = false;
            lnkSignUp.Text = "Sign In";
            SecretRow.Visible = true;
            Session["LoginMode"] = "Forget Password";
        }

        private string Encrytion(string value)
        {
            try
            {
                byte[] bytes = System.Text.Encoding.Unicode.GetBytes(value);
                string encryptedText = Convert.ToBase64String(bytes);
                return encryptedText;
            }
            catch(Exception e)
            {
                throw;
            }
        }

        private string Decryption(string value)
        {
            try
            {
                byte[] bytes = Convert.FromBase64String(value);
                string decryptedText = System.Text.Encoding.Unicode.GetString(bytes);
                return decryptedText;
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}