﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Feedback_Suraj
{
    public class DataBaseOperation
    {
        
        public string connection = ConfigurationManager.AppSettings["ConnectionString"];
        public void InsertUserDetails( string email,string password,string secretCode)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("INSERT INTO UserDetails VALUES(@email,@password,@secretCode,1,'SYSTEM',GETDATE(),'SYSTEM',GETDATE())", sqlConnection))
                    {

                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@password", password);
                        command.Parameters.AddWithValue("@secretCode", secretCode);
                        command.ExecuteNonQuery();
                    }
                    sqlConnection.Close();

                }

            }
            catch
            {

            }
            
        }
        public bool GetUserDetails(string email, string password)
        {
            bool result = false;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT TOP 1 * FROM UserDetails(NOLOCK) WHERE Email = @email AND Password = @password", sqlConnection))
                    {

                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@password", password);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                result = true;
                            }
                        }
                        sqlConnection.Close();

                    }

                }
            }
            catch
            {

            }
            return result;
        }

        public Dictionary<string, string> GetCommentsDetails()
        {
            
            Dictionary<string, string> comments = new Dictionary<string, string>();
            try
            {
                string output = string.Empty;
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT Email,Comments FROM CommentsDetails(NOLOCK) ORDER BY CmtID DESC ", sqlConnection))
                    {

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if(!comments.TryGetValue(reader["Email"].ToString(),out output))
                                {
                                    comments.Add(reader["Email"].ToString(), reader["Comments"].ToString());
                                }
                            }
                        }
                        sqlConnection.Close();

                    }

                }
            }
            catch
            {

            }
            return comments;
        }

        public void InsertCommentsDetails(string email, string comments)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("INSERT INTO CommentsDetails VALUES(@email,@comments,1,'SYSTEM',GETDATE(),'SYSTEM',GETDATE())", sqlConnection))
                    {

                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@comments", comments);
                        command.ExecuteNonQuery();
                    }
                    sqlConnection.Close();

                }

            }
            catch
            {

            }

        }

        public List<string> GetCommentsDetailsFilter(string email)
        {

            List<string> comments = new List<string>();
            try
            {
                string output = string.Empty;
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT Comments FROM CommentsDetails(NOLOCK) WHERE Email=@email ORDER BY CmtID DESC", sqlConnection))
                    {
                        command.Parameters.AddWithValue("@email", email);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string comment = reader["Comments"].ToString();
                                comments.Add(comment);
                            }
                        }
                        sqlConnection.Close();

                    }

                }
            }
            catch(Exception e)
            {

            }
            return comments;
        }
        public string GetPassword(string email, string secretcode)
        {

            string password = string.Empty;
            try
            {
                string output = string.Empty;
                using (SqlConnection sqlConnection = new SqlConnection(connection))
                {
                    sqlConnection.Open();
                    using (SqlCommand command = new SqlCommand("SELECT Password FROM UserDetails(NOLOCK) WHERE Email=@email AND SecretCode = @secretcode", sqlConnection))
                    {
                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@secretcode", secretcode);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                password = reader["Password"].ToString();
     
                            }
                        }
                        sqlConnection.Close();

                    }

                }
            }
            catch (Exception e)
            {

            }
            return password;
        }

    }
}